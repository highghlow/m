mod cache;
mod fetch;
mod missing_hashes;
mod zip;

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use anyhow::Context;
use clap::Parser;
use tokio::io::AsyncWriteExt;
use yarn_lock_parser::Lockfile;

use crate::cache::Cache;

const USER_AGENT: &str = "yarn-berry-fetcher/1";

static SUPPORTED_CACHE_VERSION: LazyLock<u8> = LazyLock::new(|| {
    std::env!("YARN_ZIP_SUPPORTED_CACHE_VERSION")
        .parse()
        .unwrap()
});

#[derive(clap::Parser)]
struct Args {
    /// Up to how many fetches to do concurrently.
    #[clap(long, default_value_t = 20)]
    fetch_concurrency: usize,

    #[command(subcommand)]
    command: Commands,
}

#[derive(PartialEq, Eq, clap::Subcommand)]
enum Commands {
    /// Download packages in the given yarn lock file to the $out directory.
    Fetch {
        #[clap(value_name = "yarn.lock")]
        lockfile_path: PathBuf,
        #[clap(value_name = "missing-hashes.json")]
        missing_hashes_path: Option<PathBuf>,
        /// The location to write packages to.
        /// If unset, the literal directory "out" will be used.
        #[clap(long, env = "out", default_value = "out")]
        out_dir: PathBuf,
    },
    /// download packages in the given yarn.lock file, and print the appropriate 'nix-hash' for it.
    Prefetch {
        #[clap(value_name = "yarn.lock")]
        lockfile_path: PathBuf,
        #[clap(value_name = "missing-hashes.json")]
        missing_hashes_path: Option<PathBuf>,
    },
    /// Produce missing hashes data, and print it to stdout.
    MissingHashes {
        #[clap(value_name = "yarn.lock")]
        lockfile_path: PathBuf,
    },
    /// Convert an npm tgz file, write it to 'out.zip'.
    Convert {
        #[clap(value_name = "full package name")]
        package_name: String,

        #[clap(value_name = "npm.tgz")]
        tgz_filename: PathBuf,
    },
}

async fn fetch(
    lockfile_path: &Path,
    missing_hashes_path: Option<impl AsRef<Path>>,
    out_dir: &Path,
    http_client: &reqwest::Client,
    fetch_concurrency: usize,
) -> anyhow::Result<()> {
    let lockfile_contents = &tokio::fs::read_to_string(&lockfile_path)
        .await
        .context("reading lockfile contents")?;
    let lockfile = parse_lockfile_ensure_version(lockfile_contents).context("parsing lockfile")?;

    let missing_hashes: HashMap<String, String> = missing_hashes_path
        .as_ref()
        .map(|path| {
            serde_json::from_slice(&std::fs::read(path).context("reading missing-hashes.json")?)
                .context("parsing missing-hashes.json")
        })
        .transpose()?
        .unwrap_or_default();

    let cache = Cache::open(out_dir, lockfile);
    cache
        .fetch_all(missing_hashes, http_client, fetch_concurrency)
        .await
        .context("fetching all sources")?;

    tokio::fs::write(out_dir.join("yarn.lock"), &lockfile_contents)
        .await
        .context("writing yarn.lock")?;
    if let Some(missing_hashes_path) = missing_hashes_path {
        std::fs::copy(missing_hashes_path, out_dir.join("missing-hashes.json"))
            .context("writing missing-hashes.json")?;
    }

    Ok(())
}

#[tokio::main(flavor = "multi_thread")]
async fn main() -> anyhow::Result<()> {
    let args = Args::parse();

    let http_client = reqwest::Client::builder()
        .user_agent(USER_AGENT)
        .build()
        .context("building http client")?;

    match args.command {
        Commands::Fetch {
            lockfile_path,
            missing_hashes_path,
            out_dir,
        } => {
            fetch(
                &lockfile_path,
                missing_hashes_path,
                &out_dir,
                &http_client,
                args.fetch_concurrency,
            )
            .await?;
        }
        Commands::Prefetch {
            lockfile_path,
            missing_hashes_path,
        } => {
            let tmp_dir = tempfile::TempDir::new().context("creating tempdir")?;
            fetch(
                &lockfile_path,
                missing_hashes_path,
                tmp_dir.path(),
                &http_client,
                args.fetch_concurrency,
            )
            .await?;

            let output = async_process::Command::new("nix-hash")
                .arg("--type")
                .arg("sha256")
                .arg("--sri")
                .arg(tmp_dir.path())
                .output()
                .await
                .context("spawning nix-hash")?;

            if !output.status.success() {
                eprintln!("nix-hash errored:");
                tokio::io::stderr().write_all(&output.stderr).await.unwrap();
                anyhow::bail!("nix-hash errored")
            }

            tmp_dir.close().context("closing tempdir")?;
            println!("{}", String::from_utf8_lossy(&output.stdout));
        }
        Commands::MissingHashes { lockfile_path } => {
            let lockfile_contents = tokio::fs::read_to_string(&lockfile_path)
                .await
                .context("reading lockfile contents")?;

            let lockfile = parse_lockfile_ensure_version(lockfile_contents.as_str())?;

            let missing_hashes =
                missing_hashes::get_missing_hashes(lockfile, &http_client, args.fetch_concurrency)
                    .await
                    .context("while getting missing hashes")?;

            println!(
                "{}",
                serde_json::to_string_pretty(&missing_hashes)
                    .context("serializing missing_hashes")?
            );
        }
        Commands::Convert {
            package_name,
            tgz_filename,
        } => {
            zip::write_yarn_zip_async(
                package_name,
                "out.zip".into(),
                tokio::fs::File::open(tgz_filename)
                    .await
                    .context("opening tgz_filename")?,
                None,
            )
            .await?;
            eprintln!("wrote out.zip");
        }
    }

    Ok(())
}

/// Parses the lockfile contents and ensures it's a supported version.
fn parse_lockfile_ensure_version(lockfile_contents: &str) -> anyhow::Result<Lockfile<'_>> {
    let lockfile =
        yarn_lock_parser::parse_str(lockfile_contents).context("parsing yarn.lock file")?;

    match lockfile.cache_key_parsed() {
        Some((cache_key_version, _compression)) => {
            if cache_key_version != *SUPPORTED_CACHE_VERSION {
                anyhow::bail!(
                    r#"
Error fetching berry dependencies.
Found cache version {}
Supported by this version of yarn-berry-fetcher: {}
Hint: Are you using fetchYarnBerryDeps from the correct yarn-berry version?"#,
                    lockfile.version,
                    *SUPPORTED_CACHE_VERSION
                );
            }
        }
        None => {
            anyhow::bail!(
                "no lockfile cache key found. Are you trying to pass a yarn v1 lockfile?"
            );
        }
    }

    Ok(lockfile)
}

pub trait LockfileExt {
    /// Parses the cache_key of the lockfile, decomposing it into cache key version and optional compression field.
    fn cache_key_parsed(&self) -> Option<(u8, Option<u32>)>;
}

impl LockfileExt for yarn_lock_parser::Lockfile<'_> {
    fn cache_key_parsed(&self) -> Option<(u8, Option<u32>)> {
        let cache_key = self.cache_key?;

        Some(match cache_key.split_once('c') {
            Some((left, right)) => (
                left.parse()
                    .expect("to parse cache_key before compression marker"),
                Some(
                    right
                        .parse()
                        .expect("to parse compression after compression marker"),
                ),
            ),
            None => (
                cache_key
                    .parse()
                    .expect("to parse cache_key without compression"),
                None,
            ),
        })
    }
}

pub trait EntryExt {
    fn name(&self) -> &str;
    fn name_rest(&self) -> &str;
    fn scope(&self) -> Option<&str>;
    fn scope_name(&self) -> Option<&str>;
    fn resolution(&self) -> &str;
    fn protocol(&self) -> &str;
    fn protocol_and_source(&self) -> Option<&str>;
    fn source_selector_and_bindings(&self) -> &str;
    fn bindings(&self) -> Option<form_urlencoded::Parse<'_>>;
    fn source_and_selector(&self) -> &str;
    fn source(&self) -> Option<&str>;
    fn selector(&self) -> &str;
    fn is_real_source(&self) -> bool;
    fn is_npm(&self) -> bool;
    fn npm_url(&self) -> String;
    fn is_tar(&self) -> bool;
    fn is_git(&self) -> bool;
    fn git_commit(&self) -> Option<&str>;
    fn integrity_sha512(&self) -> Option<&str>;
    fn slug(&self) -> String;
    fn is_content_addressed(&self) -> bool;
}

impl EntryExt for yarn_lock_parser::Entry<'_> {
    fn name(&self) -> &str {
        if self.resolved.starts_with("@") {
            let second_at = self.resolved[1..].find("@").unwrap() + 1;
            &self.resolved[..second_at]
        } else {
            self.resolved.split_once("@").unwrap().0
        }
    }

    fn name_rest(&self) -> &str {
        let name = self.name();
        match name.split_once("/") {
            None => name,
            Some((_, rest)) => rest,
        }
    }

    fn scope(&self) -> Option<&str> {
        self.name().split_once("/").map(|(scope, _)| scope)
    }

    fn scope_name(&self) -> Option<&str> {
        self.scope().map(|scope| scope.strip_prefix("@").unwrap())
    }

    fn resolution(&self) -> &str {
        if self.resolved.starts_with("@") {
            let second_at = self.resolved[1..].find("@").unwrap() + 1;
            &self.resolved[second_at + 1..]
        } else {
            self.resolved.split_once("@").unwrap().1
        }
    }

    fn protocol(&self) -> &str {
        self.resolution().split_once(":").unwrap().0
    }

    fn source_selector_and_bindings(&self) -> &str {
        self.resolution().split_once(":").unwrap().1
    }

    fn bindings(&self) -> Option<form_urlencoded::Parse<'_>> {
        let source_selector_and_bindings = self.source_selector_and_bindings();
        source_selector_and_bindings
            .rsplit_once("::")
            .map(|(_, bindings)| form_urlencoded::parse(bindings.as_bytes()))
    }

    fn source_and_selector(&self) -> &str {
        let source_selector_and_bindings = self.source_selector_and_bindings();
        source_selector_and_bindings
            .rsplit_once("::")
            .unwrap_or((source_selector_and_bindings, ""))
            .0
    }

    fn protocol_and_source(&self) -> Option<&str> {
        self.resolution()
            .split_once("#")
            .map(|(protocol_and_source, _)| protocol_and_source)
    }

    fn selector(&self) -> &str {
        let source_and_selector = self.source_and_selector();
        source_and_selector
            .split_once("#")
            .unwrap_or(("", source_and_selector))
            .1
    }

    fn source(&self) -> Option<&str> {
        self.source_and_selector()
            .split_once("#")
            .map(|(source, _selector)| source)
    }

    fn is_real_source(&self) -> bool {
        !["workspace", "patch", "link"].contains(&self.protocol())
    }

    fn npm_url(&self) -> String {
        if let Some(mut bindings) = self.bindings()
            && let Some(archive_url) = bindings
                .find(|(name, _)| name == "__archiveUrl")
                .map(|(_, archive_url)| archive_url)
            {
                return archive_url.into();
            }

        format!(
            "https://registry.npmjs.org/{}/-/{}-{}.tgz",
            self.name(),
            self.name_rest(),
            self.selector()
        )
    }

    fn is_npm(&self) -> bool {
        self.protocol() == "npm"
    }

    fn is_tar(&self) -> bool {
        let resolution = self.resolution();
        ["http", "https"].contains(&self.protocol())
            && (resolution.ends_with(".tar.gz") || resolution.ends_with(".tgz"))
    }

    fn is_git(&self) -> bool {
        self.resolution().contains(".git#")
    }

    fn git_commit(&self) -> Option<&str> {
        self.selector()
            .split("&")
            .filter_map(|pair| pair.split_once("="))
            .find(|(name, _)| name == &"commit")
            .map(|(_, commit)| commit)
    }

    fn integrity_sha512(&self) -> Option<&str> {
        let integrity = self.integrity.split("/").last().unwrap();
        if integrity.is_empty() {
            None
        } else {
            assert_eq!(integrity.len(), 128);
            Some(integrity)
        }
    }

    fn slug(&self) -> String {
        let mut slug = "".to_string();
        slug.push_str(&self.name().replace("/", "-"));
        slug.push('-');
        slug.push_str(self.protocol());
        let selector = self.selector();
        if semver::Version::parse(selector).is_ok() {
            slug.push('-');
            slug.push_str(selector);
        }
        slug
    }

    fn is_content_addressed(&self) -> bool {
        !self.integrity.is_empty()
    }
}
